THIS IS A PASSWORD GENERATOR PYHTON PROGRAM.
THESE ARE SOME OF THE OF THE COMMANDS WHICH YOU MUST KNOW
pl :- for password lenght you want
pltf :- name of the website for which you are setting password
lw :- to set the minimum length of lower case character
up :- to set the minimum length of upper case character
dg :- to set length of digit
sp :- to set special character length

function you need to call is passwordgenerator(pltf,pl,lw,up,dg,sp)
